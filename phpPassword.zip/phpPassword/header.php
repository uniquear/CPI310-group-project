<?php
    session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>PHP project 01</title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="wrapper">
            <a href="index.php"></a>
            <ul>
                <li><a href="index.php">home</a></li>
                <li><a href="discover.php">about us</a></li>
                <li><a href="blog.php">find blogs</a></li>
                <?php
                    if(isset($_SESSION["useruid"]))
                    {
                        echo "<li><a href='profile.php'>Profile page</a></li>";
                        echo "<li><a href='includes/logout.inc.php'>log out</a></li>";
                    }
                    else
                    {
                        echo "<li><a href='signup.php'>sign up</a></li>";
                        echo "<li><a href='login.php'>log in</a></li>";
                    }
                ?>
            </ul>
        </div>
    </nav>
