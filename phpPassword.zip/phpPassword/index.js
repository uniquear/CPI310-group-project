const http = require('http');
const filesys = require('fs');
const { join } = require('path');
const port = 8080;

const requestHandler = function(req,res)
{
    console.log(req.url);

    var filename = "";

    if(req.url.length > 1)
    {
        filename = "./"+req.url;
    }
    else 
    {
        filename = "./index.php";
    }

    filesys.readFile(filename, (error, file) => {

        if(error)
        {
            if(error.code === 'ENOENT')
            {
                //404 error
                res.writeHead(404);
                res.end(error.message);
            }
            console.log("Error handling:",filename);
            res.writeHead(500, error.message);
            return; //end with error
        }
        res.end(file);
    })
}

const server = http.createServer(requestHandler);

server.listen(port, (error) => {
    if(error)
    {
        return console.log("something went wrong",error);
    }

    console.log("server is listening on", port)
})